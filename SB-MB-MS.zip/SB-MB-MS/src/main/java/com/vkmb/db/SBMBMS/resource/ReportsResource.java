package com.vkmb.db.SBMBMS.resource;

import com.vkmb.db.SBMBMS.Mapper.ReportsMapper;
import com.vkmb.db.SBMBMS.model.reports;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

    @RestController
    @RequestMapping("/rest/reports")
    public class ReportsResource
    {
        private ReportsMapper reportsMapper;

        public ReportsResource(ReportsMapper reportsMapper)
        {
            this.reportsMapper = reportsMapper;
        }

        @GetMapping("/all")
        public List<reports> getAll()
        {
            return reportsMapper.findAllReports();
        }

        @GetMapping("/{id}")
        public List<reports> getById(@PathVariable int id)
        {
            return reportsMapper.findById(id);
        }

        @GetMapping("/insert")
        public List<reports> addBooks()
        {
            reports report = new reports();
            report.setBook_No(12);
            report.setIssue_Return(LocalDateTime.now());
            report.setRegisterationNo(12);
            report.setUser_ID(123);
            reportsMapper.insertReport(report);
            return reportsMapper.findAllReports();
        }

        @PostMapping(path = "/insert", consumes = "application/json", produces = "application/json")
        public List<reports> insert(@RequestBody reports report) {
            reportsMapper.insertReport(report);
            return reportsMapper.findAllReports();
        }

        @GetMapping("/delete")
        public List<reports> delete()
        {
            reports report = new reports();
            report.setBook_No(12);
            report.setIssue_Return(LocalDateTime.now());
            report.setRegisterationNo(12);
            report.setUser_ID(123);
            reportsMapper.deleteReport(report);
            return reportsMapper.findAllReports();
        }

        @GetMapping("/update")
        public List<reports> update()
        {
            reports report = new reports();
            report.setBook_No(1);
            report.setIssue_Return(LocalDateTime.now());
            report.setRegisterationNo(1);
            report.setUser_ID(202);
            reportsMapper.update(report);
            return reportsMapper.findAllReports();
        }

    }
