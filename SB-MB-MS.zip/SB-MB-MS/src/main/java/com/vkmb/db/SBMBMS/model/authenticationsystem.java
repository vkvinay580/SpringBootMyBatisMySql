package com.vkmb.db.SBMBMS.model;

public class authenticationsystem
{
    private String LoginID;
    private String Password;

    public String getLoginID()
    {
        return LoginID;
    }

    public void setLoginID(String loginID)
    {
        LoginID = loginID;
    }

    public String getPassword()
    {
        return Password;
    }

    public void setPassword(String password)
    {
        Password = password;
    }
}
