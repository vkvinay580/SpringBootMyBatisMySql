package com.vkmb.db.SBMBMS.Mapper;

import java.util.List;
import com.vkmb.db.SBMBMS.model.staff;
import org.apache.ibatis.annotations.*;

@Mapper
public interface StaffMapper
{

        @Select("SELECT * FROM staff")
        List<staff> findAllStaff();

        @Insert("Insert into staff values( #{staff_ID}, #{staff_Name})")
        @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "staff_ID", before = false,resultType = String.class)
        void insertStaff(staff staff);

        @Delete("DELETE FROM staff WHERE (staff_Id = #{staff_ID})")
        void deleteStaff(staff staff);

        @Update("UPDATE staff set Staff_Id = #{staff_ID},Staff_Name = #{staff_Name} WHERE (staff_Id = #{staff_ID})")
        void update(staff staff);

        @Select("SELECT * FROM staff WHERE (staff_Id = #{staff_ID})")
        List<staff> findById(String id);
}
