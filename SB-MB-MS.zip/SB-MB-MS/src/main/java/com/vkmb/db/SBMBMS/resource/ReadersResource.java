package com.vkmb.db.SBMBMS.resource;

import com.vkmb.db.SBMBMS.Mapper.ReadersMapper;
import com.vkmb.db.SBMBMS.model.readers;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/readers")
public class ReadersResource
{

    private ReadersMapper readersMapper;

    public ReadersResource(ReadersMapper readersMapper)
    {
        this.readersMapper = readersMapper;
    }

    @GetMapping("/all")
    public List<readers> getAll()
    {
        return readersMapper.findAllReaders();
    }

    @GetMapping("/{id}")
    public List<readers> getById(@PathVariable int id)
    {
        return readersMapper.findById(id);
    }

    @GetMapping("/insert")
    public List<readers> addReaders()
    {
        readers reader = new readers();
        reader.setUser_Id(10);
        reader.setEmail("vkvk@lib.com");
        reader.setPhone(8745985);
        reader.setAdDress("Hungary");
        reader.setReader_FirstName("vinay");
        reader.setReader_LastName("karthik");
        readersMapper.insertReaders(reader);
        return readersMapper.findAllReaders();
    }

    @PostMapping(path = "/insert", consumes = "application/json", produces = "application/json")
    public List<readers> addReaders(@RequestBody readers reader)
    {
        readersMapper.insertReaders(reader);
        return readersMapper.findAllReaders();
    }

    @GetMapping("/delete")
    public List<readers> delete()
    {
        readers reader = new readers();
        reader.setUser_Id(10);
        reader.setEmail("vkvk@lib.com");
        reader.setPhone(8745985);
        reader.setAdDress("Hungary");
        reader.setReader_FirstName("vinay");
        reader.setReader_LastName("karthik");
        readersMapper.deleteReaders(reader);
        return readersMapper.findAllReaders();
    }

    @GetMapping("/update")
    public List<readers> update()
    {
        readers reader = new readers();
        reader.setUser_Id(10);
        reader.setEmail("vkvk@lib.com");
        reader.setPhone(8745985);
        reader.setAdDress("Hungary");
        reader.setReader_FirstName("vinay");
        reader.setReader_LastName("karthik");
        readersMapper.update(reader);
        return readersMapper.findAllReaders();
    }

}