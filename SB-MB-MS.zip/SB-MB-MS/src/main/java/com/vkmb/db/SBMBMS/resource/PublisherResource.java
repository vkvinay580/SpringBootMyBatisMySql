package com.vkmb.db.SBMBMS.resource;

import com.vkmb.db.SBMBMS.Mapper.PublisherMapper;
import com.vkmb.db.SBMBMS.model.publisher;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/publishers")
public class PublisherResource
{

    private PublisherMapper publisherMapper;

    public PublisherResource(PublisherMapper publisherMapper)
    {
        this.publisherMapper = publisherMapper;
    }

    @GetMapping("/all")
    public List<publisher> getAll()
    {
        return publisherMapper.findAllPublisher();
    }

    @GetMapping("/{id}")
    public List<publisher> getById(@PathVariable String id)
    {
        return publisherMapper.findById(id);
    }

    @GetMapping("/insert")
    public List<publisher> insertPublisher()
    {
        publisher publisher = new publisher();
        publisher.setPublisher_ID("AU");
        publisher.setName("ALLEN AND UNWIN");
        publisher.setPublicationYear(1976);
        publisherMapper.insertPublisher(publisher);
        return publisherMapper.findAllPublisher();
    }

    @PostMapping(path = "/insert", consumes = "application/json", produces = "application/json")
    public List<publisher> update(@RequestBody publisher publisher){
        publisherMapper.update(publisher);

        return publisherMapper.findAllPublisher();
    }

    @GetMapping("/delete")
    public List<publisher> delete()
    {
        publisher publisher = new publisher();
        publisher.setPublisher_ID("BB10");
        publisher.setName("BANTAM BOOKS");
        publisher.setPublicationYear(2018);
        publisherMapper.deletePublisher(publisher);
        return publisherMapper.findAllPublisher();
    }
    @GetMapping("/update")
    public List<publisher> update()
    {
        publisher publisher = new publisher();
        publisher.setPublisher_ID("AU");
        publisher.setName("ALLEN AND UNWIN");
        publisher.setPublicationYear(1976);
        publisherMapper.update(publisher);
        return publisherMapper.findAllPublisher();
    }

}