package com.vkmb.db.SBMBMS.Mapper;

import com.vkmb.db.SBMBMS.model.reports;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface ReportsMapper
{

        @Select("SELECT * FROM reports")
        List<reports> findAllReports();

        @Insert("Insert into reports values( #{user_ID}, #{registerationNo},#{Book_No},#{issue_Return})")
        @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "user_ID", before = false,resultType = Integer.class)
        void insertReport(reports reports);

        @Delete("Delete FROM reports WHERE ( User_Id = #{user_ID})")
        void deleteReport(reports reports);

        @Update("UPDATE reports set user_ID = #{user_ID},registerationNo = #{registerationNo},Book_No = #{Book_No},issue_Return = #{issue_Return} WHERE ( user_ID = #{user_ID})")
        void update(reports reports);

        @Select("SELECT * FROM reports WHERE ( User_Id = #{user_ID})")
        List<reports> findById(int id);
}
