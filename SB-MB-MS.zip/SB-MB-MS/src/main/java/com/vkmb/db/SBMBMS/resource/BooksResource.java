package com.vkmb.db.SBMBMS.resource;

import com.vkmb.db.SBMBMS.Mapper.BooksMapper;
import com.vkmb.db.SBMBMS.model.authenticationsystem;
import com.vkmb.db.SBMBMS.model.books;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/books")
public class BooksResource
{

    private BooksMapper bookMapper;

    public BooksResource(BooksMapper bookMapper)
    {
        this.bookMapper = bookMapper;
    }

    @GetMapping("/all")
    public List<books> getAll()
    {
        return bookMapper.findAllBooks();
    }

    @GetMapping("/{id}")
    public List<books> getById(@PathVariable int id)
    {
        return bookMapper.findById(id);
    }

    @PostMapping(path = "/insert", consumes = "application/json", produces = "application/json")
    public List<books> addBook(@RequestBody books book)
    {
        bookMapper.insertBook(book);
        return bookMapper.findAllBooks();
    }


    @GetMapping("/insert")
    public List<books> addBook()
    {
        books book = new books();
        book.setISBN(19);
        book.setCategory("FICTION");
        book.setEdition(1);
        book.setPrice(32);
        book.setTitle("FIRE AND BLOOD");
        book.setAuthNo("GEORGE R MARTIN");
        bookMapper.insertBook(book);
        return bookMapper.findAllBooks();
    }

    @GetMapping("/delete")
    public List<books> delete()
    {
        books book = new books();
        book.setISBN(19);
        book.setCategory("FICTION");
        book.setEdition(1);
        book.setPrice(123);
        book.setTitle("FIRE AND BLOOD");
        book.setAuthNo("GEORGE R MARTIN");
        bookMapper.deleteBooks(book);
        return bookMapper.findAllBooks();
    }

    @GetMapping("/update")
    public List<books> update()
    {
        books book = new books();
        book.setISBN(202);
        book.setCategory("FICTION");
        book.setEdition(1);
        book.setPrice(123);
        book.setTitle("HARRY POTTER2");
        book.setAuthNo("JKROWLING");
        bookMapper.update(book);
        return bookMapper.findAllBooks();
    }

}