package com.vkmb.db.SBMBMS.Mapper;

import com.vkmb.db.SBMBMS.model.readers;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface ReadersMapper
{
    @Select("SELECT * FROM readers")
    List<readers> findAllReaders();

    @Insert("insert into readers values(#{User_Id},#{Email},#{Phone},#{AdDress},#{Reader_FirstName},#{reader_LastName})")
    @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "User_Id" , before = false, resultType = Integer.class)
    void insertReaders(readers readers);

    @Delete("delete from readers where (User_Id = #{User_Id})")
    void deleteReaders(readers readers);

    @Update("UPDATE readers set User_Id = #{User_Id},Email = #{Email},Phone = #{Phone},AdDress = #{AdDress}, Reader_FirstName = #{Reader_FirstName}, reader_LastName = #{reader_LastName} where(User_Id = #{User_Id})")
    void update(readers readers);

    @Select("SELECT * FROM readers WHERE ( User_Id = #{User_Id})")
    List<readers> findById(int id);
}
