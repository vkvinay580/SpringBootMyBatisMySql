package com.vkmb.db.SBMBMS.model;

import java.time.LocalDateTime;

public class reports
{

    private int user_ID;
    private int registerationNo;
    private int Book_No;
    private LocalDateTime issue_Return;

    public int getUser_ID()
    {
        return user_ID;
    }

    public void setUser_ID(int user_ID)
    {
        this.user_ID = user_ID;
    }

    public int getRegisterationNo()
    {
        return registerationNo;
    }

    public void setRegisterationNo(int registerationNo)
    {
        this.registerationNo = registerationNo;
    }

    public int getBook_No()
    {
        return Book_No;
    }

    public void setBook_No(int book_No)
    {
        Book_No = book_No;
    }

    public LocalDateTime getIssue_Return()
    {
        return issue_Return;
    }

    public void setIssue_Return(LocalDateTime issue_Return)
    {
        this.issue_Return = issue_Return;
    }
}
