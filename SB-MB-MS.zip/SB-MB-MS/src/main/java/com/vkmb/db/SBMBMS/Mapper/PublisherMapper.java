package com.vkmb.db.SBMBMS.Mapper;

import com.vkmb.db.SBMBMS.model.publisher;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface PublisherMapper
{
    @Select("SELECT * FROM publisher")
    List<publisher> findAllPublisher();

    @Insert("insert into publisher values(#{publisher_ID},#{name},#{publicationYear})")
    @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "publisher_ID" , before = false, resultType = String.class)
    void insertPublisher(publisher publisher);

    @Delete("delete from publisher where(Publisher_Id = #{publisher_ID}")
    void deletePublisher(publisher publisher);

    @Update("update publisher set Publisher_Id = #{publisher_ID},Name = #{name},PublicationYear = #{publicationYear} where(Publisher_Id = #{publisher_ID})")
    void update(publisher publisher);

    @Select("SELECT * FROM publisher WHERE ( Publisher_Id = #{publisher_ID}")
    List<publisher> findById(String id);
}

