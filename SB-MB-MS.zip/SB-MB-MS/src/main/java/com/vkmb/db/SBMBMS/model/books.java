package com.vkmb.db.SBMBMS.model;

public class books
{
    private int ISBN;
    private int Price;
    private String Category;
    private String Title;
    private int Edition;
    private String AuthNo;

    public int getISBN()
    {
        return ISBN;
    }

    public void setISBN(int ISBN)
    {
        this.ISBN = ISBN;
    }

    public int getPrice()
    {
        return Price;
    }

    public void setPrice(int price)
    {
        Price = price;
    }

    public String getCategory()
    {
        return Category;
    }

    public void setCategory(String category)
    {
        Category = category;
    }

    public String getTitle()
    {
        return Title;
    }

    public void setTitle(String title)
    {
        Title = title;
    }

    public int getEdition()
    {
        return Edition;
    }

    public void setEdition(int edition)
    {
        Edition = edition;
    }

    public String getAuthNo()
    {
        return AuthNo;
    }

    public void setAuthNo(String authNo)
    {
        AuthNo = authNo;
    }
}
