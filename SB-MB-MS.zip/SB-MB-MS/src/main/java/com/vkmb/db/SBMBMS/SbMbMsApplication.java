package com.vkmb.db.SBMBMS;

import com.vkmb.db.SBMBMS.model.*;
import org.apache.ibatis.type.MappedTypes;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MappedTypes({books.class, authenticationsystem.class, publisher.class, readers.class,reports.class, staff.class})
@MapperScan("com.vkmb.db.SBMBMS.Mapper")
@SpringBootApplication
public class SbMbMsApplication
{
	public static void main(String[] args)
	{
		SpringApplication.run(SbMbMsApplication.class, args);
	}
}
