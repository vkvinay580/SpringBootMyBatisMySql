package com.vkmb.db.SBMBMS.Mapper;

import com.vkmb.db.SBMBMS.model.authenticationsystem;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface AuthenticationSystemMapper
{
    @Select("SELECT * FROM authenticationsystem")
    List<authenticationsystem> findAllAuthentication();

    @Insert("insert into authenticationsystem values(#{LoginID},#{Password})")
    @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "LoginID" , before = false, resultType = String.class)
    void insertAuthenticationSystem(authenticationsystem authenticationsystem);

    @Delete("delete from authenticationsystem where(LoginID = #{LoginID}")
    void deleteAuthenticationSystem(authenticationsystem authenticationsystem);

    @Update("update authenticationsystem set LoginID = #{LoginID}, Password = #{Password} where(LoginID = #{LoginID})")
    void update(authenticationsystem authenticationSystem);

    @Select("SELECT * FROM authenticationsystem WHERE ( LoginID = #{LoginID}")
    List<authenticationsystem> findById(String id);
}

