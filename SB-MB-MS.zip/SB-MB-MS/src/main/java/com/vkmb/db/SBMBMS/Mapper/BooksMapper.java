package com.vkmb.db.SBMBMS.Mapper;

import com.vkmb.db.SBMBMS.model.books;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface BooksMapper
{
    @Select("SELECT * FROM books")
    List<books> findAllBooks();

    @Insert("insert into books values(#{ISBN},#{Price},#{Category},#{Title},#{Edition},#{AuthNo})")
    @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "ISBN" , before = false, resultType = Integer.class)
    void insertBook(books books);

    @Delete("delete from books where(ISBN = #{ISBN})")
    void deleteBooks(books book);

    @Update("UPDATE books set ISBN = #{ISBN},Price = #{Price},Category = #{Category},Title = #{Title}, Edition = #{Edition} where(ISBN = #{ISBN})")
    void update(books book);

    @Select("SELECT * FROM books WHERE ( ISBN = #{ISBN})")
    List<books> findById(int id);
}
