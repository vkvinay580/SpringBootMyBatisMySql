package com.vkmb.db.SBMBMS.resource;

import com.vkmb.db.SBMBMS.Mapper.StaffMapper;
import com.vkmb.db.SBMBMS.model.staff;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/staff")
public class Staffresource
{
    private StaffMapper staffMapper;

    public Staffresource(StaffMapper staffmapper)
    {
        this.staffMapper = staffmapper;
    }

    @GetMapping("/all")
    public List<staff> getAll()
    {
        return staffMapper.findAllStaff();
    }

    @GetMapping("/{id}")
    public List<staff> getById(@PathVariable String id)
    {
        return staffMapper.findById(id);
    }

    @GetMapping("/insert")
    public List<staff> addBooks()
    {
        staff staff = new staff();
        staff.setStaff_ID("AZ");
        staff.setStaff_Name("AlHassan Zghaibe");
        staffMapper.insertStaff(staff);
        return staffMapper.findAllStaff();
    }

    @PostMapping(path = "/insert", consumes = "application/json", produces = "application/json")
    public List<staff> insert(@RequestBody staff staff)
    {
        staffMapper.insertStaff(staff);
        return staffMapper.findAllStaff();
    }

    @GetMapping("/delete")
    public List<staff> deleteStaff()
    {
        staff staff = new staff();
        staff.setStaff_ID("AZ");
        staff.setStaff_Name("AlHassan Zghaibe");
        staffMapper.deleteStaff(staff);
        return staffMapper.findAllStaff();
    }

    @GetMapping("/update")
    public List<staff> update()
    {
        staff staff = new staff();
        staff.setStaff_ID("NEW");
        staff.setStaff_Name("NEW UPDATE");
        staffMapper.update(staff);
        return staffMapper.findAllStaff();
    }
}