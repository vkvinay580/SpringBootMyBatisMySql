package com.vkmb.db.SBMBMS.resource;

import com.vkmb.db.SBMBMS.Mapper.AuthenticationSystemMapper;
import com.vkmb.db.SBMBMS.model.authenticationsystem;
import org.springframework.web.bind.annotation.*;

import java.util.List;

    @RestController
    @RequestMapping("/rest/AuthenticationSystem")
    public class AuthenticationSystemResource
    {

        private AuthenticationSystemMapper authenticationSystemMapper;

        public AuthenticationSystemResource(AuthenticationSystemMapper authenticationSystemMapper)
        {
            this.authenticationSystemMapper = authenticationSystemMapper;
        }

        @GetMapping("/all")
        public List<authenticationsystem> getAll()
        {
            return authenticationSystemMapper.findAllAuthentication();
        }

        @GetMapping("/{id}")
        public List<authenticationsystem> getById(@PathVariable String id)
        {
            return authenticationSystemMapper.findById(id);
        }

        @PostMapping(path = "/insert", consumes = "application/json", produces = "application/json")
        public List<authenticationsystem> addAuthentication(@RequestBody authenticationsystem authenticationsystem)
        {
            authenticationSystemMapper.insertAuthenticationSystem(authenticationsystem);
            return authenticationSystemMapper.findAllAuthentication();
        }

        @GetMapping("/insert")
        public List<authenticationsystem> addAuthentication()
        {
            authenticationsystem authenticationsystem = new authenticationsystem();
            authenticationsystem.setLoginID("vkvkvk@lib.com");
            authenticationsystem.setPassword("vkvkvk@123");
            authenticationSystemMapper.insertAuthenticationSystem(authenticationsystem);
            return authenticationSystemMapper.findAllAuthentication();
        }

        @GetMapping("/delete")
        public List<authenticationsystem> delete()
        {
            authenticationsystem authenticationsystem = new authenticationsystem();
            authenticationsystem.setLoginID("vkvkvk@lib.com");
            authenticationsystem.setPassword("vkvkvk@123");
            authenticationSystemMapper.deleteAuthenticationSystem(authenticationsystem);
            return authenticationSystemMapper.findAllAuthentication();
        }

        @GetMapping("/update")
        public List<authenticationsystem> update()
        {
            authenticationsystem authenticationSystem = new authenticationsystem();
            authenticationSystem.setLoginID("VK");
            authenticationSystem.setPassword("vkvkvk@123");
            authenticationSystemMapper.update(authenticationSystem);
            return authenticationSystemMapper.findAllAuthentication();
        }
    }

