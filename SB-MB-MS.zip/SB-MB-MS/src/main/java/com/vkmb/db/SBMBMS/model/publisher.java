package com.vkmb.db.SBMBMS.model;

public class publisher
{

    private String publisher_ID;
    private String name;
    private int publicationYear;

    public String getPublisher_ID()
    {
        return publisher_ID;
    }

    public void setPublisher_ID(String publisher_ID)
    {
        this.publisher_ID = publisher_ID;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getPublicationYear()
    {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear)
    {
        this.publicationYear = publicationYear;
    }
}
