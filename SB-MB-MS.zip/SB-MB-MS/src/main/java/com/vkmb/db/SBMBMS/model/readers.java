package com.vkmb.db.SBMBMS.model;

public class readers
{

private int User_Id;
private String Email;
private int Phone;
private String AdDress;
private String Reader_FirstName;
private String Reader_LastName;

    public int getUser_Id()
    {
        return User_Id;
    }

    public void setUser_Id(int user_Id)
    {
        User_Id = user_Id;
    }

    public String getEmail()
    {
        return Email;
    }

    public void setEmail(String email)
    {
        Email = email;
    }

    public int getPhone()
    {
        return Phone;
    }

    public void setPhone(int phone)
    {
        Phone = phone;
    }

    public String getAdDress()
    {
        return AdDress;
    }

    public void setAdDress(String adDress)
    {
        AdDress = adDress;
    }

    public String getReader_FirstName()
    {
        return Reader_FirstName;
    }

    public void setReader_FirstName(String reader_FirstName)
    {
        Reader_FirstName = reader_FirstName;
    }

    public String getReader_LastName()
    {
        return Reader_LastName;
    }

    public void setReader_LastName(String reader_LastName)
    {
        Reader_LastName = reader_LastName;
    }
}
